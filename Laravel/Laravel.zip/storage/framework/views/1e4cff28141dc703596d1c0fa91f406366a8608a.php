<?php $__env->startSection('content'); ?>
<form action="<?php echo e(URL::route('avisos.store')); ?>"
method="post">

<div class="form-group row">
<div class="col-sm-4"></div>
<div class="col-md-6">
<h2>Criar Aviso:</h2>
</div>
</div>

<div class="form-group row">
<label for="aviso" class="col-sm-4 col-form-label text-md-right">Aviso:</label>
<div class="col-md-6">
<input type="text" id="aviso" class="form-control" name="aviso"><br>
</div>
</div>

<div class="form-group row">
<label for="tipo" class="col-sm-4 col-form-label text-md-right">Tipo:</label>
<div class="col-md-6">
<select id="tipo" name="tipo" class="form-control" ><option value="0">Geral</option><option value="1">Restrito</option></select><br>
</div>
</div>

<div class="form-group row">
<div class="col-md-4"></div>
<div class="col-md-6">
<input type="submit"  class="btn btn-info">
<input type="hidden" name="_token" 
value="<?php echo e(csrf_token()); ?>">
</div>
</div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>