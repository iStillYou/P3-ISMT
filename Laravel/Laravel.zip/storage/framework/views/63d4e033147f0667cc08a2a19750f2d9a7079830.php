<?php $__env->startSection('content'); ?>
<form action="<?php echo e(URL::route('horarios.store')); ?>" enctype="multipart/form-data"
method="post">

<div class="form-group row">
<div class="col-sm-4"></div>
<div class="col-md-6">
<h2>Criar Horários Escolar:</h2>
</div>
</div>

<div class="form-group row">
<label for="data" class="col-sm-4 col-form-label text-md-right">Dia semana:</label>
<div class="col-md-6">
<input type="diasemana" id="diasemana" class="form-control" name="diasemana"><br>
</div>
</div>

<div class="form-group row">
<label for="hora" class="col-sm-4 col-form-label text-md-right">Hora (Ínicio - Fim) :</label>
<div class="col-md-6">
<input type="text" id="hora" class="form-control" name="hora"><br>
</div>
</div>

<div class="form-group row">
<label for="texto" class="col-sm-4 col-form-label text-md-right">Aula:</label>
<div class="col-md-6">
<input type="text" id="texto" class="form-control" name="texto"><br>
</div>
</div>

<div class="form-group row">
<label for="anoLetivo" class="col-sm-4 col-form-label text-md-right">Ano (1º, 2º , 3º):</label>
<div class="col-md-6">
<input type="text" id="anoLetivo" class="form-control" name="anoLetivo"><br>
</div>
</div>

<div class="form-group row">
<div class="col-md-4"></div>
<div class="col-md-6">
<input type="submit"  class="btn btn-info">
<input type="hidden" name="_token" 
value="<?php echo e(csrf_token()); ?>">
</div>
</div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>