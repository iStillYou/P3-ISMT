<?php $__env->startSection('content'); ?>

 <div class="content">
                <div class="title m-b-md">
                    Bem-vindo ao ISMT App
                </div>

                <div class="links">
               
                <?php if(Route::has('login')): ?>
             
                    <?php if(auth()->guard()->check()): ?>
                    
                        <a href="<?php echo e(route('home')); ?>">Ínicio</a>
                        <a href="<?php echo e(URL::to('utilizadores')); ?>">Utilizadores</a>
                        <a href="<?php echo e(URL::to('emprego')); ?>">Pro. de Emprego</a>
                        <a href="<?php echo e(URL::to('horarios')); ?>">Horários Escolares</a>
                        <a href="<?php echo e(URL::to('docentes')); ?>">Docentes</a>
                        <a href="<?php echo e(URL::to('propinas')); ?>">Propinas</a>
                        <a href="<?php echo e(URL::to('semestre')); ?>">Cal. Escolar</a>
                        <a href="<?php echo e(URL::to('exames')); ?>">Exames</a>
                        <a href="<?php echo e(URL::to('avisos')); ?>">Avisos</a>
                        <a href="<?php echo e(URL::to('noticias')); ?>">Notícias</a>
                    
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                       
                    <?php endif; ?>
               
            <?php endif; ?>
                </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>