<?php $__env->startSection('content'); ?>
<div class="form-group row">
<div class="col-md-3"></div>
<div class="col-md-6 ">
<h2>Listagem das Propinas</h2>
<br>
<table class="table table-border">
<tr>
<th>Nº </th>

<th>Tipo</th>
<th>Ínicio</th>
<th>Fim</th>
<th>Descrição</th>
<th>Editar/Eliminar</td>
</tr>
<?php foreach($semestres as $semestre): ?>
<tr>
<td><?php echo $semestre->id; ?></td>
<td><?php echo $semestre->tipo; ?></td>
<td><?php echo $semestre->inicio; ?></td>
<td><?php echo $semestre->fim; ?></td>
<td><?php echo $semestre->texto; ?></td>
<td>


<a class="btn btn-small btn-warning form-control" href="<?php echo e(URL::to('semestre/' . $semestre->id . '/edit')); ?>">Editar</a>
<br>
<br>

<?php echo e(Form::open(array('url' => 'semestre/' . $semestre->id, 'class' => 'pull-right'))); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <?php echo e(Form::submit('Eliminar', array('class' => 'btn btn-small btn-danger form-control'))); ?>

<?php echo e(Form::close()); ?>



</td>

</tr>
<?php endforeach ?>
</table>
</div>
</div>
<div class="form-group row">
<div class="col-md-3"></div>
<div class="col-md-6">
<a class="btn btn-small btn-info" href="<?php echo e(URL::route('semestre.create')); ?>">Novo Calendário</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>