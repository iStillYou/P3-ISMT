<?php $__env->startSection('content'); ?>

<div class="form-group row">
<div class="col-sm-4"></div>

<div class="col-md-6">
<h2>Edit <?php echo e($noticia->titulo); ?></h2>

<!-- if there are creation errors, they will show here -->
<?php echo e(HTML::ul($errors->all())); ?>


<?php echo e(Form::model($noticia, array('route' => array('noticias.update', $noticia->id), 'method' => 'PUT', 'files' => true))); ?>


    <div class="form-group">
        <?php echo e(Form::label('titulo', 'Titulo')); ?>

        <?php echo e(Form::text('titulo', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('texto', 'Texto')); ?>

        <?php echo e(Form::textarea('texto', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('data', 'Data')); ?>

        <?php echo e(Form::text('data', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('imagem', 'Imagem')); ?>

        <?php echo e(Form::file('imagem', null, array('class' => 'form-control'))); ?>

    </div>

    <?php echo e(Form::submit('Submeter', array('class' => 'btn btn-primary'))); ?>


<?php echo e(Form::close()); ?>

</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>