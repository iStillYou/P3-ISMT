<?php $__env->startSection('content'); ?>

<div class="form-group row">
<div class="col-sm-4"></div>

<div class="col-md-6">
<h2>Edit <?php echo e($propina->id); ?></h2>

<!-- if there are creation errors, they will show here -->
<?php echo e(HTML::ul($errors->all())); ?>


<?php echo e(Form::model($propina, array('route' => array('propinas.update', $propina->id), 'method' => 'PUT', 'files' => true))); ?>


    <div class="form-group">
        <?php echo e(Form::label('anoLetivo', 'Ano Letivo:')); ?>

        <?php echo e(Form::text('anoLetivo', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('dataLimite', 'Data de Limite:')); ?>

        <?php echo e(Form::date('dataLimite', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('tipoDePagamento', 'Tipo de Pagamento:')); ?>

        <?php echo e(Form::text('tipoDePagamento', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('valor', 'Valor:')); ?>

        <?php echo e(Form::text('valor', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('estado', 'Estado:')); ?>

        <?php echo e(Form::select('estado', array('1' => 'A pagamento', '2' => 'Em atraso'), null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('idUtilizador', 'Utilizador:')); ?>

        <?php echo e(Form::select('idUtilizador', $utilizadores, null, array('class' => 'form-control'))); ?>

    </div>

    
    

    <?php echo e(Form::submit('Submeter', array('class' => 'btn btn-primary'))); ?>


<?php echo e(Form::close()); ?>

</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>