<?php $__env->startSection('content'); ?>

<div class="form-group row">
<div class="col-sm-4"></div>

<div class="col-md-6">
<h2>Edit <?php echo e($utilizadores->username); ?></h2>

<!-- if there are creation errors, they will show here -->
<?php echo e(HTML::ul($errors->all())); ?>


<?php echo e(Form::model($utilizadores, array('route' => array('utilizadores.update', $utilizadores->id), 'method' => 'PUT', 'files' => true))); ?>


    <div class="form-group">
        <?php echo e(Form::label('username', 'Nome do utlizador')); ?>

        <?php echo e(Form::text('username', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('password', 'Senha')); ?>

        <?php echo e(Form::password('password', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('privilegio', 'Privilégio')); ?>

        <?php echo e(Form::select('privilegio', array('0' => 'Aluno', '1' => 'Professor'), null, array('class' => 'form-control'))); ?>

    </div>

    <?php echo e(Form::submit('Submeter', array('class' => 'btn btn-primary'))); ?>


<?php echo e(Form::close()); ?>

</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>