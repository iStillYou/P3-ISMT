<?php $__env->startSection('content'); ?>

<div class="form-group row">
<div class="col-sm-4"></div>

<div class="col-md-6">
<h2>Edit <?php echo e($horario->texto); ?></h2>

<!-- if there are creation errors, they will show here -->
<?php echo e(HTML::ul($errors->all())); ?>


<?php echo e(Form::model($horario, array('route' => array('horarios.update', $horario->id), 'method' => 'PUT', 'files' => true))); ?>


    <div class="form-group">
        <?php echo e(Form::label('diasemana', 'Dia da Semana:')); ?>

        <?php echo e(Form::text('diasemana', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('hora', 'Hora (Ínicio - Fim):')); ?>

        <?php echo e(Form::text('hora', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('texto', 'Aula:')); ?>

        <?php echo e(Form::text('texto', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('anoLetivo', 'Ano (1º, 2º, 3º):')); ?>

        <?php echo e(Form::text('anoLetivo', null, array('class' => 'form-control'))); ?>

    </div>
    

    <?php echo e(Form::submit('Submeter', array('class' => 'btn btn-primary'))); ?>


<?php echo e(Form::close()); ?>

</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>