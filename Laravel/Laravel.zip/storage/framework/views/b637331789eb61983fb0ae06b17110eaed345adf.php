<?php $__env->startSection('content'); ?>

<div class="form-group row">
<div class="col-sm-4"></div>

<div class="col-md-6">
<h2>Edit <?php echo e($docente->nome); ?></h2>

<!-- if there are creation errors, they will show here -->
<?php echo e(HTML::ul($errors->all())); ?>


<?php echo e(Form::model($docente, array('route' => array('docentes.update', $docente->id), 'method' => 'PUT', 'files' => true))); ?>


    <div class="form-group">
        <?php echo e(Form::label('nome', 'Nome completo:')); ?>

        <?php echo e(Form::text('nome', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('professor', 'Categoria profissional:')); ?>

        <?php echo e(Form::text('professor', null, array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('email', 'Email:')); ?>

        <?php echo e(Form::text('email', null, array('class' => 'form-control'))); ?>

    </div>

    
    

    <?php echo e(Form::submit('Submeter', array('class' => 'btn btn-primary'))); ?>


<?php echo e(Form::close()); ?>

</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>